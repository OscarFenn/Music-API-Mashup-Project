function getInfo(){
	var search = $('#search').val();

  var infourl = 'http://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=' + search +'&api_key=ac83636465b06e3626587c01f7d85bba&format=json'

  $.get(infourl, function(response){
    var info = response.artist.bio.summary;


   $('#result').html(info);


  })
};

//Run function on click
$('#submit').click(getInfo);